class Book {
  final String title;
  final String author;
  final String genre;
  final String imagePath;
  final String description;
  int clicks; // Nombre de fois que le livre a été cliqué
  final int? popularity; // Popularité (optionnelle)
  final DateTime? dateAdded; // Date d'ajout (optionnelle)

  Book({
    required this.title,
    required this.author,
    required this.genre,
    required this.imagePath,
    required this.description,
    this.clicks = 0, // valeur par défaut = 0
    this.popularity,
    this.dateAdded,
  });
}
