import 'package:flutter/material.dart';
import '../models/book.dart';
import '../utils/data.dart';
import '../services/recommendation_service.dart';
import '../widgets/book_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final RecommendationService _service = RecommendationService(allBooks);

  // Recherche et filtres
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  String? _selectedGenre;
  String _selectedSort = "A-Z";

  List<String> genres = ["All", "Fiction", "Science-Fiction", "Fantasy", "Roman Philosophique", "Classique", "Horreur", "Romance", "Poésie", "Thriller Psychologique", "Cyberpunk", "Satire", "Drame"];
  List<String> sortOptions = ["A-Z", "Z-A", "Plus populaire", "Date ajout"];

  List<Book> get filteredBooks {
    List<Book> books = allBooks;

    // Filtrer par genre
    if (_selectedGenre != null && _selectedGenre != "All") {
      books = books.where((b) => b.genre == _selectedGenre).toList();
    }

    // Filtrer par recherche
    if (_searchQuery.isNotEmpty) {
      books = books
          .where((b) => b.title.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    }

    // Trier
    if (_selectedSort == "A-Z") {
      books.sort((a, b) => a.title.compareTo(b.title));
    } else if (_selectedSort == "Z-A") {
      books.sort((a, b) => b.title.compareTo(a.title));
    } else if (_selectedSort == "Plus populaire") {
      books.sort((a, b) => (b.popularity ?? 0).compareTo(a.popularity ?? 0));
    } else if (_selectedSort == "Date ajout") {
      books.sort((a, b) => (b.dateAdded ?? DateTime.now()).compareTo(a.dateAdded ?? DateTime.now()));
    }

    return books;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookwise'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // Champ de recherche
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Rechercher un livre...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
            const SizedBox(height: 10),

            // Filtre par genre
            SizedBox(
              height: 50,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: genres
                    .map((genre) => Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _selectedGenre = genre;
                              });
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _selectedGenre == genre
                                  ? Colors.deepPurple
                                  : Colors.grey[300],
                            ),
                            child: Text(
                              genre,
                              style: TextStyle(
                                color: _selectedGenre == genre
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),

            const SizedBox(height: 10),

            // Tri
            Row(
              children: [
                const Text("Trier par : "),
                const SizedBox(width: 10),
                DropdownButton<String>(
                  value: _selectedSort,
                  items: sortOptions
                      .map((sort) => DropdownMenuItem(
                            value: sort,
                            child: Text(sort),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedSort = value!;
                    });
                  },
                ),
              ],
            ),

            const SizedBox(height: 10),

            // Liste des livres
            Expanded(
              child: filteredBooks.isEmpty
                  ? const Center(child: Text("Aucun livre trouvé"))
                  : ListView.builder(
                      itemCount: filteredBooks.length,
                      itemBuilder: (context, index) {
                        return BookCard(book: filteredBooks[index]);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
