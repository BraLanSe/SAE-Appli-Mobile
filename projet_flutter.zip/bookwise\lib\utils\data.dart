import '../models/book.dart';

final List<Book> allBooks = [
  Book(
    title: 'Le petit prince',
    author: 'Antoine de Saint-Exupéry',
    genre: 'Fiction',
    imagePath: 'assets/images/petit_prince.jpg',
    description:
        'Le Petit Prince est un conte poétique qui explore les thèmes de l’innocence, de la solitude et de la perte.',
    clicks: 0,
    popularity: 100,
    dateAdded: DateTime(2023, 1, 1),
  ),
  Book(
    title: '1984',
    author: 'George Orwell',
    genre: 'Science-Fiction',
    imagePath: 'assets/images/1984.jpg',
    description:
        '1984 décrit une société totalitaire où chaque citoyen est surveillé en permanence.',
    clicks: 0,
    popularity: 95,
    dateAdded: DateTime(2023, 2, 1),
  ),
  Book(
    title: 'Harry Potter à l’école des sorciers',
    author: 'J.K. Rowling',
    genre: 'Fantasy',
    imagePath: 'assets/images/harry_potter.jpg',
    description:
        'Premier tome de la saga Harry Potter, ce roman raconte l’entrée de Harry dans le monde magique.',
    clicks: 0,
    popularity: 120,
    dateAdded: DateTime(2023, 3, 1),
  ),
  Book(
    title: 'Le Seigneur des Anneaux : La Communauté de l’Anneau',
    author: 'J.R.R. Tolkien',
    genre: 'Fantasy',
    imagePath: 'assets/images/lotr_communaut.jpg',
    description:
        'Frodon Sacquet hérite d’un anneau mystérieux et entreprend un voyage périlleux avec une communauté de héros.',
    clicks: 0,
    popularity: 110,
    dateAdded: DateTime(2023, 4, 1),
  ),
  Book(
    title: 'Dune',
    author: 'Frank Herbert',
    genre: 'Science-Fiction',
    imagePath: 'assets/images/dune.jpg',
    description:
        'Considéré comme l’un des plus grands romans de science-fiction, Dune se déroule sur la planète Arrakis.',
    clicks: 0,
    popularity: 105,
    dateAdded: DateTime(2023, 5, 1),
  ),
  Book(
    title: 'Le Hobbit',
    author: 'J.R.R. Tolkien',
    genre: 'Fantasy',
    imagePath: 'assets/images/le_hobbit.jpg',
    description:
        'Bilbo Bessac est entraîné dans une aventure avec treize nains pour reconquérir leur trésor gardé par le dragon Smaug.',
    clicks: 0,
    popularity: 102,
    dateAdded: DateTime(2023, 6, 1),
  ),
  Book(
    title: 'L’Alchimiste',
    author: 'Paulo Coelho',
    genre: 'Roman Philosophique',
    imagePath: 'assets/images/l_alchimiste.jpg',
    description:
        'Santiago, un jeune berger, part à la recherche d’un trésor et découvre la sagesse universelle.',
    clicks: 0,
    popularity: 98,
    dateAdded: DateTime(2023, 7, 1),
  ),
  Book(
    title: 'Fondation',
    author: 'Isaac Asimov',
    genre: 'Science-Fiction',
    imagePath: 'assets/images/fondation.jpg',
    description:
        'Hari Seldon prédit la chute de l’Empire galactique et fonde la Fondation pour préserver le savoir humain.',
    clicks: 0,
    popularity: 97,
    dateAdded: DateTime(2023, 8, 1),
  ),
  Book(
    title: 'Les Misérables',
    author: 'Victor Hugo',
    genre: 'Classique',
    imagePath: 'assets/images/les_miserables.jpg',
    description:
        'Jean Valjean, ancien forçat en quête de rédemption, est poursuivi par Javert dans une France tourmentée.',
    clicks: 0,
    popularity: 99,
    dateAdded: DateTime(2023, 9, 1),
  ),
  Book(
    title: 'L’Assassin Royal : L’Apprenti Assassin',
    author: 'Robin Hobb',
    genre: 'Fantasy',
    imagePath: 'assets/images/assassin_royal1.jpg',
    description:
        'Fitz, fils illégitime d’un prince, est élevé dans l’ombre pour devenir un assassin royal.',
    clicks: 0,
    popularity: 88,
    dateAdded: DateTime(2023, 10, 1),
  ),
  Book(
    title: 'Shining',
    author: 'Stephen King',
    genre: 'Horreur',
    imagePath: 'assets/images/shining.jpg',
    description:
        'Jack Torrance accepte un poste de gardien d’hiver dans un hôtel isolé et sombre dans la folie.',
    clicks: 0,
    popularity: 92,
    dateAdded: DateTime(2023, 11, 1),
  ),
  Book(
    title: 'Autant en emporte le vent',
    author: 'Margaret Mitchell',
    genre: 'Romance Historique',
    imagePath: 'assets/images/autant_en_emporte_le_vent.jpg',
    description:
        'Scarlett O’Hara tente de survivre et de préserver sa famille pendant la guerre de Sécession.',
    clicks: 0,
    popularity: 90,
    dateAdded: DateTime(2023, 12, 1),
  ),
  Book(
    title: 'Les Fleurs du mal',
    author: 'Charles Baudelaire',
    genre: 'Poésie',
    imagePath: 'assets/images/les_fleurs_du_mal.jpg',
    description:
        'Les Fleurs du mal explore la beauté, le spleen et la quête de l’idéal dans la poésie française.',
    clicks: 0,
    popularity: 85,
    dateAdded: DateTime(2024, 1, 1),
  ),
  Book(
    title: 'La Voleuse de livres',
    author: 'Markus Zusak',
    genre: 'Drame',
    imagePath: 'assets/images/la_voleuse_de_livres.jpg',
    description:
        'L’histoire est narrée par la Mort et suit Liesel, une jeune fille allemande durant la Seconde Guerre mondiale.',
    clicks: 0,
    popularity: 93,
    dateAdded: DateTime(2024, 2, 1),
  ),
  Book(
    title: 'Le Nom du Vent',
    author: 'Patrick Rothfuss',
    genre: 'Fantasy',
    imagePath: 'assets/images/le_nom_du_vent.jpg',
    description:
        'Kvothe raconte sa propre histoire : enfance tragique, passage à l’Université et aventures extraordinaires.',
    clicks: 0,
    popularity: 91,
    dateAdded: DateTime(2024, 3, 1),
  ),
  Book(
    title: 'La Horde du Contrevent',
    author: 'Alain Damasio',
    genre: 'Science-Fiction',
    imagePath: 'assets/images/la_horde_du_contrevent.jpg',
    description:
        'Une troupe d’élite lutte contre des vents violents dans une quête existentielle.',
    clicks: 0,
    popularity: 89,
    dateAdded: DateTime(2024, 4, 1),
  ),
  Book(
    title: 'Neuromancien',
    author: 'William Gibson',
    genre: 'Cyberpunk',
    imagePath: 'assets/images/neuromancien.jpg',
    description:
        'Case, un hacker déchu, est recruté pour une mission impossible dans un futur cyberpunk.',
    clicks: 0,
    popularity: 87,
    dateAdded: DateTime(2024, 5, 1),
  ),
  Book(
    title: 'Orgueil et Préjugés',
    author: 'Jane Austen',
    genre: 'Romance',
    imagePath: 'assets/images/orgueil_et_prejuges.jpg',
    description:
        'Elizabeth Bennet navigue dans les relations complexes de la société anglaise et rencontre Mr Darcy.',
    clicks: 0,
    popularity: 94,
    dateAdded: DateTime(2024, 6, 1),
  ),
  Book(
    title: 'Le Parfum',
    author: 'Patrick Süskind',
    genre: 'Thriller Psychologique',
    imagePath: 'assets/images/le_parfum.jpg',
    description:
        'Jean-Baptiste Grenouille, né sans odeur, cherche à créer le parfum parfait et sombre dans l’obsession.',
    clicks: 0,
    popularity: 96,
    dateAdded: DateTime(2024, 7, 1),
  ),
  Book(
    title: 'La Ferme des animaux',
    author: 'George Orwell',
    genre: 'Satire',
    imagePath: 'assets/images/la_ferme_des_animaux.jpg',
    description:
        'Une allégorie politique où des animaux de ferme renversent leur propriétaire humain pour instaurer un nouvel ordre.',
    clicks: 0,
    popularity: 86,
    dateAdded: DateTime(2024, 8, 1),
  ),
];
